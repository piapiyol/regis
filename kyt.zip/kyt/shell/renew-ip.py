import os
import datetime
import requests
from git import Repo, GitCommandError

# Set environment variable for HOME
os.environ['HOME'] = '/root'

# // PROJECT ROZ STORE
url_izin = "https://raw.githubusercontent.com/RozTun/permission/main/ip"
IP = requests.get('https://ipv4.icanhazip.com').text.strip()
data_server = requests.head('https://google.com').headers['Date']
date_list = datetime.datetime.strptime(data_server, '%a, %d %b %Y %H:%M:%S GMT').strftime('%Y-%m-%d')

def checking_sc():
    response = requests.get(url_izin).text
    useexp = None
    for line in response.splitlines():
        if IP in line:
            useexp = line.split()[2]
            break
    if useexp and date_list < useexp:
        pass
    else:
        print("\033[1;93m────────────────────────────────────────────\033[0m")
        print("\033[42m          404 NOT FOUND AUTOSCRIPT          \033[0m")
        print("\033[1;93m────────────────────────────────────────────\033[0m")
        print("")
        print(f"            \033[31mPERMISSION DENIED !\033[0m")
        print(f"   \033[0;33mYour VPS\033[0m {IP} \033[0;33mHas been Banned\033[0m")
        print(f"     \033[0;33mBuy access permissions for scripts\033[0m")
        print(f"             \033[0;33mContact Admin :\033[0m")
        print(f"      \033[0;36mWhatsapp\033[0m wa.me/6282240074362")
        print("\033[1;93m────────────────────────────────────────────\033[0m")
        exit()

def extend_ip_expiry(ip, exp_days):
    response = requests.get('https://pastebin.com/raw/ABHhVMDw').text
    userscript, emailscript, tokenscript = response.splitlines()[0].split()

    today = datetime.datetime.now().strftime('%Y-%m-%d')
    repo_dir = '/root/ipvps'
    if not os.path.exists(repo_dir):
        os.makedirs(repo_dir)

    if not os.path.exists(f'{repo_dir}/ip'):
        Repo.clone_from(f'https://github.com/{userscript}/permission.git', repo_dir)

    lines = []
    ip_found = False
    with open(f'{repo_dir}/ip', 'r') as file:
        lines = file.readlines()
        for i, line in enumerate(lines):
            if ip in line:
                parts = line.split()
                exp_date = datetime.datetime.strptime(parts[2], '%Y-%m-%d')
                new_exp_date = (exp_date + datetime.timedelta(days=exp_days)).strftime('%Y-%m-%d')
                lines[i] = f"{parts[0]} {parts[1]} {new_exp_date} {parts[3]}\n"
                ip_found = True
                break

    if not ip_found:
        print("IP Not Found!")
        os.system(f'rm -rf {repo_dir}')
        return "IP Not Found"

    with open(f'{repo_dir}/ip', 'w') as file:
        file.writelines(lines)

    repo = Repo(repo_dir)
    repo.git.config('--global', 'user.email', emailscript)
    repo.git.config('--global', 'user.name', userscript)
    repo.git.init()
    repo.git.add(A=True)
    repo.index.commit('extend expiry')
    repo.git.branch('-M', 'main')

    try:
        origin = repo.remote(name='origin')
        origin.set_url(f'https://{tokenscript}@github.com/{userscript}/permission.git')
    except ValueError:
        repo.create_remote('origin', url=f'https://{tokenscript}@github.com/{userscript}/permission.git')

    try:
        repo.git.push('origin', 'main', force=True)
    except GitCommandError as e:
        print(f"Error during push: {e}")
        return "Push failed"

    os.system(f'rm -rf {repo_dir}')
    return "Successfully extended IP expiry"

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 3:
        print("Usage: python renew.py <ip> <expiry_days>")
        sys.exit(1)

    ip = sys.argv[1]
    exp_days = int(sys.argv[2])
    result = extend_ip_expiry(ip, exp_days)
    print(result)